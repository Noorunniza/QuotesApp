//
//  QuotesAppApp.swift
//  QuotesApp
//
//  Created by DDUKK on 09/08/1947 Saka.
//

import SwiftUI

@main
struct QuotesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
