//
//  Quote.swift
//  QuotesApp
//
//  Created by DDUKK on 09/08/1947 Saka.
//

import Foundation

struct Quote : Identifiable{
    let id = UUID()
    var text : String
}
